var interface_k_w_i_m_nav_v_ctrlr =
[
    [ "tableView:cellForRowAtIndexPath:", "interface_k_w_i_m_nav_v_ctrlr.html#a39ffecad2efb22f315b88433bfe28a41", null ],
    [ "tableView:numberOfRowsInSection:", "interface_k_w_i_m_nav_v_ctrlr.html#a39c9d23f301431c123d84391d8dcdcf1", null ]
];