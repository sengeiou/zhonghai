var interface_s_b_json_stream_parser =
[
    [ "parse:", "interface_s_b_json_stream_parser.html#a9c4b15221e738a1eb49079e266daa1bf", null ],
    [ "delegate", "interface_s_b_json_stream_parser.html#a1a4e90ce1ca9b55e7696db77ef6bf20c", null ],
    [ "error", "interface_s_b_json_stream_parser.html#a49c6e710bc367cdc627a4152706f1008", null ],
    [ "maxDepth", "interface_s_b_json_stream_parser.html#a1c6f49cb5dd676452994d96498bb5a3f", null ],
    [ "state", "interface_s_b_json_stream_parser.html#aa0bce27e23cb3e352564b5f57876f0e5", null ],
    [ "stateStack", "interface_s_b_json_stream_parser.html#a7f7df2e29f60e02d63888e4e8c3ee5b0", null ],
    [ "supportMultipleDocuments", "interface_s_b_json_stream_parser.html#afd976c605b67edbb8b7abbebcc5b4093", null ]
];