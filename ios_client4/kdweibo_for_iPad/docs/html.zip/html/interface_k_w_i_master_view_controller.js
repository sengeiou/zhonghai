var interface_k_w_i_master_view_controller =
[
    [ "detailViewController", "interface_k_w_i_master_view_controller.html#a2b086a73c1cb6def9da4160e616ceee2", null ],
    [ "fetchedResultsController", "interface_k_w_i_master_view_controller.html#a27ea4e1620277413a9ef8495456ed0d7", null ],
    [ "managedObjectContext", "interface_k_w_i_master_view_controller.html#ac7f2a10a0fe8153ed18980f648011331", null ]
];