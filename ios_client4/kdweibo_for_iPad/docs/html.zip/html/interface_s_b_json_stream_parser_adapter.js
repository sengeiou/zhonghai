var interface_s_b_json_stream_parser_adapter =
[
    [ "delegate", "interface_s_b_json_stream_parser_adapter.html#a9d336f9c9e1caf3291f80918cb13188e", null ],
    [ "levelsToSkip", "interface_s_b_json_stream_parser_adapter.html#a1b7451c67d9149b14632c228909659bb", null ]
];