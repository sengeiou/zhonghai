var protocol_k_w_engine_delegate-p =
[
    [ "accessTokenRecieved:forRequest:", "protocol_k_w_engine_delegate-p.html#a3cf0042e39ece45babf67ec82dce0853", null ],
    [ "recievedHomeTimeline:forRequest:", "protocol_k_w_engine_delegate-p.html#abeea5d62c462e08d0b7e37a7d09aa43b", null ],
    [ "requestFailed:withError:", "protocol_k_w_engine_delegate-p.html#a7e4b66f1b5c2c9821effc51c4d943dde", null ],
    [ "requestSucceeded:withResponse:", "protocol_k_w_engine_delegate-p.html#ad4fafadea685adb97f087d49814de7f7", null ],
    [ "XAuthFailed:withError:", "protocol_k_w_engine_delegate-p.html#a0b57ebc2370a839929089b7aa231d698", null ]
];