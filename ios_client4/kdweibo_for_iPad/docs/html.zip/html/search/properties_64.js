var searchData=
[
  ['delegate',['delegate',['../interface_s_b_json_stream_parser.html#a1a4e90ce1ca9b55e7696db77ef6bf20c',1,'SBJsonStreamParser::delegate()'],['../interface_s_b_json_stream_parser_adapter.html#a9d336f9c9e1caf3291f80918cb13188e',1,'SBJsonStreamParserAdapter::delegate()'],['../interface_s_b_json_stream_writer.html#a28dc79aeee865687fafdf84836c1444d',1,'SBJsonStreamWriter::delegate()']]]
];
