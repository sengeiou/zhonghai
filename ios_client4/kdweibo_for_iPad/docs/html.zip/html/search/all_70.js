var searchData=
[
  ['post_3awithparams_3aonsuccess_3a',['post:withParams:onSuccess:',['../interface_k_w_engine.html#aff4fa61650b2f6ea7670c3d939183dd2',1,'KWEngine']]],
  ['providerwithapi_3a',['providerWithApi:',['../interface_k_w_data_provider.html#ac10dbea6e0b85d4d116d44921e7a858d',1,'KWDataProvider']]]
];
