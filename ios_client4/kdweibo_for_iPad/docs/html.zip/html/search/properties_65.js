var searchData=
[
  ['error',['error',['../interface_s_b_json_parser.html#ad80719ec3d8be2bc45f06ec9c804997d',1,'SBJsonParser::error()'],['../interface_s_b_json_stream_parser.html#a49c6e710bc367cdc627a4152706f1008',1,'SBJsonStreamParser::error()'],['../interface_s_b_json_stream_writer.html#a7b4739905d4f23e82e5efd14b8acabea',1,'SBJsonStreamWriter::error()'],['../interface_s_b_json_writer.html#abc3f1e7299df08c56837d6c8ad135421',1,'SBJsonWriter::error()']]]
];
