var searchData=
[
  ['isauthenticated',['isAuthenticated',['../interface_k_w_engine.html#ac2048c4300ed0c92531f1482c63f74df',1,'KWEngine']]],
  ['isvalid',['isValid',['../interface_k_w_o_auth_token.html#a1a6324eef33e9d75ad0788bb8dad4f29',1,'KWOAuthToken']]]
];
