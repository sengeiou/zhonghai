var searchData=
[
  ['nsmanagedobject',['NSManagedObject',['../class_n_s_managed_object.html',1,'']]]
];
