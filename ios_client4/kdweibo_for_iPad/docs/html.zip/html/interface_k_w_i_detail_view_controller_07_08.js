var interface_k_w_i_detail_view_controller_07_08 =
[
    [ "configureView", "interface_k_w_i_detail_view_controller_07_08.html#a5a36b1ac11f13cf454ae324777bb4747", null ],
    [ "masterPopoverController", "interface_k_w_i_detail_view_controller_07_08.html#a30cc7281d0ad9406550897685625ce36", null ]
];