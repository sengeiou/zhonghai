var interface_k_w_data_provider =
[
    [ "appendHomeTimelnie", "interface_k_w_data_provider.html#a26fbd9408c25702c4e0addc3fd6bf452", null ],
    [ "providerWithApi:", "interface_k_w_data_provider.html#ac10dbea6e0b85d4d116d44921e7a858d", null ],
    [ "recievedHomeTimeline:forRequest:", "interface_k_w_data_provider.html#a00b3c2ccaee2eed700148aafb06db5f2", null ],
    [ "refreshHomeTimeline", "interface_k_w_data_provider.html#acbbbe337438dabc17192788351c5a8e8", null ],
    [ "sharedProvider", "interface_k_w_data_provider.html#a6dbf65166778c641102743975ab543c8", null ],
    [ "api", "interface_k_w_data_provider.html#af35a4d5197c1c441b356d06caff3e313", null ]
];