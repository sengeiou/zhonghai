var interface_k_w_i_m_nav_cell =
[
    [ "iconV", "interface_k_w_i_m_nav_cell.html#a32d256161baa719b612305d33ae3d7c1", null ],
    [ "labelV", "interface_k_w_i_m_nav_cell.html#a0713222893d6bb0203f8dfbaaf35ee49", null ],
    [ "unreadCountV", "interface_k_w_i_m_nav_cell.html#a5c0bca813361a51db23d1f97dc25c8f3", null ]
];