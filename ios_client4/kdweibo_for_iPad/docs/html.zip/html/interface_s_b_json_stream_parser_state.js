var interface_s_b_json_stream_parser_state =
[
    [ "isError", "interface_s_b_json_stream_parser_state.html#a8d04c21bcd093e5817bdbff30f39ba46", null ],
    [ "name", "interface_s_b_json_stream_parser_state.html#ae150e3c382beb444010927434679cf77", null ],
    [ "needKey", "interface_s_b_json_stream_parser_state.html#aab97dd88c338d285cc9aca7f21875ae1", null ],
    [ "parser:shouldAcceptToken:", "interface_s_b_json_stream_parser_state.html#a4c82e9be435d6f393bf5a0467c1e83eb", null ],
    [ "parser:shouldTransitionTo:", "interface_s_b_json_stream_parser_state.html#a5ed454a903b6bd268f1c1b373e243013", null ],
    [ "parserShouldReturn:", "interface_s_b_json_stream_parser_state.html#a7ba884f572ebae244fd252055aed25fc", null ],
    [ "sharedInstance", "interface_s_b_json_stream_parser_state.html#ad17b227a54da2a32a63e5d1f586f0109", null ]
];