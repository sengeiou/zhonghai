var interface_k_w_i_master_view_controller_07_08 =
[
    [ "configureCell:atIndexPath:", "interface_k_w_i_master_view_controller_07_08.html#a2ebb18f253d1a9c9299e3e8ae613cea2", null ]
];