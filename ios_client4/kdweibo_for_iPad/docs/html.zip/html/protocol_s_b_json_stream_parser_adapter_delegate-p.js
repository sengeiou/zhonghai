var protocol_s_b_json_stream_parser_adapter_delegate-p =
[
    [ "parser:foundArray:", "protocol_s_b_json_stream_parser_adapter_delegate-p.html#acac3b4b2e4cfb45a8ca8ca945a47e326", null ],
    [ "parser:foundObject:", "protocol_s_b_json_stream_parser_adapter_delegate-p.html#abefd538a1ce6d75eb3e8572a1049f597", null ]
];