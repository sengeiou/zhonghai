var interface_k_w_i_detail_view_controller =
[
    [ "detailDescriptionLabel", "interface_k_w_i_detail_view_controller.html#a8a4a17c4278926347d1d67350bb52be7", null ],
    [ "detailItem", "interface_k_w_i_detail_view_controller.html#a792432eae68f95fd771036a9af5fa9b2", null ]
];