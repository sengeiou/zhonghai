var interface_k_w_i_app_delegate =
[
    [ "applicationDocumentsDirectory", "interface_k_w_i_app_delegate.html#ad14dc7f4f70f8dd14ac6e02f06a3eb4e", null ],
    [ "saveContext", "interface_k_w_i_app_delegate.html#a9fc408d1260686557d9a794c425af812", null ],
    [ "managedObjectContext", "interface_k_w_i_app_delegate.html#aa01a2a2cf58be910cabf75f2e795b83f", null ],
    [ "managedObjectModel", "interface_k_w_i_app_delegate.html#a87e97682d079ca3b263d8db1af0c29bc", null ],
    [ "persistentStoreCoordinator", "interface_k_w_i_app_delegate.html#a32841e61c1df175051dee82669665f97", null ],
    [ "splitViewController", "interface_k_w_i_app_delegate.html#a2c3b61a03a9aa70406e02e8bbd2e7ad4", null ],
    [ "window", "interface_k_w_i_app_delegate.html#aa310a7cf7a736166c552c7f5ebadb295", null ]
];