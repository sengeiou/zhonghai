var interface_s_b_json_u_t_f8_stream =
[
    [ "appendData:", "interface_s_b_json_u_t_f8_stream.html#a64b3d20e0373bfbb5bd2dd29b1b1919f", null ],
    [ "getNextUnichar:", "interface_s_b_json_u_t_f8_stream.html#a0a813e17d9a1e2638a8d5a58a524b055", null ],
    [ "getStringFragment:", "interface_s_b_json_u_t_f8_stream.html#ad44b3e7d4f21e8ac2c7b730a0e54dc76", null ],
    [ "getUnichar:", "interface_s_b_json_u_t_f8_stream.html#a74153b4e039bcb2626a6162b8c9024c1", null ],
    [ "haveRemainingCharacters:", "interface_s_b_json_u_t_f8_stream.html#acf91817d2bd973b1f8b2cb828bc9e5f2", null ],
    [ "skip", "interface_s_b_json_u_t_f8_stream.html#aa3bb83bf9ee2ebc7d8eed0cbcd35729f", null ],
    [ "skipCharacters:length:", "interface_s_b_json_u_t_f8_stream.html#acdbfede2e91d9eba153d707be4f37d27", null ],
    [ "skipWhitespace", "interface_s_b_json_u_t_f8_stream.html#a724e347ce0f65d66276e978f5e8dd2d2", null ],
    [ "stringWithRange:", "interface_s_b_json_u_t_f8_stream.html#a1069f840be77cd74bd1d38cbdcb2146c", null ],
    [ "index", "interface_s_b_json_u_t_f8_stream.html#ac1851614a43a1be306e1804f8008e473", null ]
];